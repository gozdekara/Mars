﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HepsiBurada.Common
{
    public enum Directions
    {
        N = 1,
        S = 2,
        E = 3,
        W = 4
    }
}
