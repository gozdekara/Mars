﻿using HepsiBurada.Common.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HepsiBurada.Common
{
    public class Position : MarsRoverPosition, IPosition
    {
        public Position()
        {
            XPosition = YPosition = 0;
            Direction = Directions.N;
        }

        public void StartMoving(List<int> theLastMaxPoints, string marsRoverMovesLine)
        {
            foreach (var move in marsRoverMovesLine)
            {
                switch (move)
                {
                    case 'M':
                        MoveInTheSameDirection();
                        break;
                    case 'L':
                        TurnNinetyLeft();
                        break;
                    case 'R':
                        RotateNinetyRight();
                        break;
                    default:
                        Console.WriteLine(" Pls Enter right Character Line" + move);
                        break;
                }

                if (XPosition < 0 || XPosition > theLastMaxPoints[0] || YPosition < 0 || YPosition > theLastMaxPoints[1])
                {
                    throw new Exception(" Check the Character length {0} {1}" + theLastMaxPoints[0] + " " + theLastMaxPoints[1]);
                }
            }

        }
        private void TurnNinetyLeft()
        {
            switch (this.Direction)
            {
                case Directions.N:
                    this.Direction = Directions.W;
                    break;
                case Directions.S:
                    this.Direction = Directions.E;
                    break;
                case Directions.E:
                    this.Direction = Directions.N;
                    break;
                case Directions.W:
                    this.Direction = Directions.S;
                    break;
                default:
                    break;
            }
        }

        private void RotateNinetyRight()
        {
            switch (this.Direction)
            {
                case Directions.N:
                    this.Direction = Directions.E;
                    break;
                case Directions.S:
                    this.Direction = Directions.W;
                    break;
                case Directions.E:
                    this.Direction = Directions.S;
                    break;
                case Directions.W:
                    this.Direction = Directions.N;
                    break;
                default:
                    break;
            }
        }

        private void MoveInTheSameDirection()
        {
            switch (this.Direction)
            {
                case Directions.N:
                    this.YPosition += 1;
                    break;
                case Directions.S:
                    this.YPosition -= 1;
                    break;
                case Directions.E:
                    this.XPosition += 1;
                    break;
                case Directions.W:
                    this.XPosition -= 1;
                    break;
                default:
                    break;
            }
        }
    }
}
