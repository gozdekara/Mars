﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HepsiBurada.Common
{
    public class MarsRoverPosition
    {
        public int XPosition { get; set; }
        public int YPosition { get; set; }
        public Directions Direction { get; set; }
    }
}
