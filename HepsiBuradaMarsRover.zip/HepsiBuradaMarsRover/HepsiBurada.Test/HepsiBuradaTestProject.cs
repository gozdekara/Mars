﻿using System;
using System.Text;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using HepsiBurada.Common;

namespace HepsiBurada.Test
{
    /// <summary>
    /// Summary description for HepsiBuradaTestProject
    /// </summary>
    [TestClass]
    public class HepsiBuradaTestProject
    {

        [TestMethod]
        public void FirstTestLM()
        {
            Position position = new Position()
            {
                XPosition = 1,
                YPosition = 2,
                Direction = Directions.N
            };

            var theLastMaxPoints = new List<int>() { 5, 5 };
            var marsRoverMovesLine = "LMLMLMLMM";

            position.StartMoving(theLastMaxPoints, marsRoverMovesLine);

            var actualOutput = position.XPosition + " " + position.YPosition +" " + position.Direction.ToString();
            var expectedOutput = "1 3 N";

            Assert.AreEqual(expectedOutput, actualOutput);
        }
        [TestMethod]
        public void FirstTestMM()
        {
            Position position = new Position()
            {
                XPosition = 3,
                YPosition = 3,
                Direction = Directions.E
            };

            var theLastMaxPoints = new List<int>() { 5, 5 };
            var marsRoverMovesLine = "MRRMMRMRRM";

            position.StartMoving(theLastMaxPoints, marsRoverMovesLine);

            var actualOutput = position.XPosition + " " + position.YPosition + " " + position.Direction.ToString();
            var expectedOutput = "2 3 S";

            Assert.AreEqual(expectedOutput, actualOutput);
        }
    }
}
