﻿using HepsiBurada.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HepsiBurada
{
    class Program
    {
        static void Main(string[] args)
        {
            var theLastMaxPoints = Console.ReadLine().Trim().Split(' ').Select(int.Parse).ToList();
            var startPositions = Console.ReadLine().Trim().Split(' ');

            Position position = new Position();

            if (startPositions.Count() == 3)
            {
                position.XPosition = Convert.ToInt32(startPositions[0]);
                position.YPosition = Convert.ToInt32(startPositions[1]);
                position.Direction = (Directions)Enum.Parse(typeof(Directions), startPositions[2]);
            }
            else
            {
                Console.WriteLine("Max start position length should be 3. Pls check it ");
            }

            var marsRoverMovesLine = Console.ReadLine().ToUpper();

            try
            {
                position.StartMoving(theLastMaxPoints, marsRoverMovesLine);
                Console.WriteLine("The X Position and Y Position with Direction {0} {1} {2}", position.XPosition,position.YPosition, position.Direction.ToString());
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            Console.ReadLine();
        }
    }
}
